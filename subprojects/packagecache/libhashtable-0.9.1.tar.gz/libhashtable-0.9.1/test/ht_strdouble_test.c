/**
 * @file ht_strdouble_test.c
 * @brief Test program for string->double hashtable.
 *
 * Project: libhashtable
 * URL: https://github.com/berrym/libhashtable
 *
 * @author Michael Berry <trismegustis@gmail.com>
 * @copyright Copyright (c) 2024 Michael Berry
 * @license MIT
 */

#include "ht.h"

#include <stdio.h>
#include <stdlib.h>

int main(void) {
    ht_strdouble_t *ht = NULL;

    ht = ht_strdouble_create(&(ht_str_options_t){.case_insensitive = true});
    if (!ht) {
        exit(EXIT_FAILURE);
    }

    double i = 123.456;
    const double *a = &i;
    const double *b;

    ht_strdouble_insert(ht, "Abc", a);
    b = ht_strdouble_get(ht, "Abc");
    printf("%lf: %p, %p\n", *((double *)b), a, b);

    i = 456.789;
    ht_strdouble_insert(ht, "aBc", a);
    b = ht_strdouble_get(ht, "Abc");
    printf("%lf: %p, %p\n", *((double *)b), a, b);

    ht_strdouble_remove(ht, "abC");

    const size_t len = 20;
    char a_key[64] = {'\0'};
    double a_val = 0;

    for (size_t i = 0; i < len; i++) {
        snprintf(a_key, sizeof(a_key), "a%zu", i);
        a_val = (i * 100.5) + i + (i / 2.5);
        ht_strdouble_insert(ht, a_key, &a_val);
    }

    ht_enum_t *he = NULL;

    he = ht_strdouble_enum_create(ht);
    if (!he) {
        ht_strdouble_destroy(ht);
        exit(EXIT_FAILURE);
    }

    const char *key = NULL;
    while (ht_strdouble_enum_next(he, &key, &b)) {
        printf("key=%s, val=%lf\n", key, *((double *)b));
    }

    ht_strdouble_enum_destroy(he);
    ht_strdouble_destroy(ht);

    return 0;
}
